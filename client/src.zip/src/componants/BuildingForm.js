// src/pages/BuildingForm.js
import React, { useState } from 'react';

const BuildingForm = ({ buildings, setBuildings }) => {
  const [buildingName, setBuildingName] = useState('');

  const addBuilding = () => {
    if (buildingName) {
      setBuildings([...buildings, { name: buildingName, offices: [] }]);
      setBuildingName('');
    }
  };

  return (
    <div className="form-section">
      <h2>اضف مبني</h2>
      <input
        type="text"
        value={buildingName}
        onChange={(e) => setBuildingName(e.target.value)}
        placeholder="Building Name"
      />
      <button onClick={addBuilding}>اضف</button>
    </div>
  );
};

export default BuildingForm;
