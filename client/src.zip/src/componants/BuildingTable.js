// // src/pages/BuildingTable.js
// import React from 'react';

// const BuildingTable = ({ buildings, searchTerm, setBuildings, setSelectedBuilding, setSelectedOffice }) => {
//   const filteredBuildings = buildings.filter(building =>
//     building.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//     building.offices.some(office => office.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//     office.employees.some(employee => employee.toLowerCase().includes(searchTerm.toLowerCase())))
//   );

//   // Add update and delete functions here...

//   return (
//     <div className="data-display">
//       <h2>Buildings and Offices</h2>
//       {filteredBuildings.length === 0 ? (
//         <p>No buildings or offices match the search criteria.</p>
//       ) : (
//         <table>
//           <thead>
//             <tr>
//               <th>Building Name</th>
//               <th>Office Name</th>
//               <th>Employees</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {filteredBuildings.map((building, buildingIndex) =>
//               building.offices.map((office, officeIndex) => (
//                 <tr key={office.name}>
//                   <td>{building.name}</td>
//                   <td>{office.name}</td>
//                   <td>{office.employees.join(', ')}</td>
//                   <td>
//                     {/* Add buttons for editing and deleting */}
//                   </td>
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       )}
//     </div>
//   );
// };

// export default BuildingTable;


// src/componants/BuildingTable.js
// src/componants/BuildingTable.js
import React from 'react';

const BuildingTable = ({ buildings, employees, handleEditEmployee, handleDeleteEmployee }) => {
  return (
    <div>
       

     
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Building</th>
            <th>Office</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.id}>
              <td>{employee.name}</td>
              <td>{employee.building}</td>
              <td>{employee.office}</td>
              <td>
                <button onClick={() => handleEditEmployee(employee)}>Editeee</button>
                <button onClick={() => handleDeleteEmployee(employee.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BuildingTable;
