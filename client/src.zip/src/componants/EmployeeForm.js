// 
// src/componants/EmployeeForm.js
import React, { useState } from 'react';

const EmployeeForm = ({ buildings, setBuildings, employees, setEmployees }) => {
  const [employeeName, setEmployeeName] = useState('');
  const [selectedBuilding, setSelectedBuilding] = useState('');
  const [selectedOffice, setSelectedOffice] = useState('');
  const [editingEmployee, setEditingEmployee] = useState(null);

  const handleAddOrUpdateEmployee = () => {
    if (editingEmployee) {
      // Update existing employee
      setEmployees((prev) =>
        prev.map((employee) =>
          employee.id === editingEmployee.id
            ? { ...employee, name: employeeName, building: selectedBuilding, office: selectedOffice }
            : employee
        )
      );
      setEditingEmployee(null);
    } else {
      // Add new employee
      const newEmployee = {
        id: Date.now(),
        name: employeeName,
        building: selectedBuilding,
        office: selectedOffice,
      };
      setEmployees((prev) => [...prev, newEmployee]);
    }
    // Reset fields
    setEmployeeName('');
    setSelectedBuilding('');
    setSelectedOffice('');
  };

  const handleEdit = (employee) => {
    setEmployeeName(employee.name);
    setSelectedBuilding(employee.building);
    setSelectedOffice(employee.office);
    setEditingEmployee(employee);
  };

  const handleDelete = (id) => {
    setEmployees((prev) => prev.filter((employee) => employee.id !== id));
  };

  return (
    <div>
      <h2>اضافه موظف</h2>
      <input
        type="text"
        value={employeeName}
        onChange={(e) => setEmployeeName(e.target.value)}
        placeholder="Employee Name"
      />
      <select
        value={selectedBuilding}
        onChange={(e) => setSelectedBuilding(e.target.value)}
      >
        <option value="">Select Building</option>
        {buildings.map((building) => (
          <option key={building.name} value={building.name}>
            {building.name}
          </option>
        ))}
      </select>
      <select
        value={selectedOffice}
        onChange={(e) => setSelectedOffice(e.target.value)}
      >
        <option value="">Select Office</option>
        {selectedBuilding &&
          buildings.find((b) => b.name === selectedBuilding)?.offices.map((office) => (
            <option key={office.name} value={office.name}>
              {office.name}
            </option>
          ))}
      </select>
      <button onClick={handleAddOrUpdateEmployee}>
        {editingEmployee ? 'Update Employee' : 'Add Employee'}
      </button>

    
    </div>
  );
};

export default EmployeeForm;
