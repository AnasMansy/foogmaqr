// src/pages/FilterSection.js
import React from 'react';

const FilterSection = ({ filters, onFilterChange }) => {
  const handleChange = (e) => {
    onFilterChange(e.target.name, e.target.value);
  };

  return (
    <div className="filter-section">
      <input
        type="text"
        name="name"
        placeholder="ابحث بالاسم"
        value={filters.name}
        onChange={handleChange}
      />
      <input
        type="text"
        name="phone"
        placeholder="ابحث برقم الهاتف"
        value={filters.phone}
        onChange={handleChange}
      />
      <select name="building" value={filters.building} onChange={handleChange}>
        <option value="">كل المباني</option>
        <option value="الجناح الايسر">الجناح الايسر</option>
        <option value="الجناح الايمن">الجناح الايمن</option>
        <option value="الهندسيه">الهندسيه</option>
        <option value="الماليه">الماليه</option>
      </select>
      <select name="office" value={filters.office} onChange={handleChange}>
        <option value="">كل الادارات</option>
        <option value="101">101</option>
        <option value="202">202</option>
        <option value="303">303</option>
        <option value="404">404</option>
      </select>
    </div>
  );
};

export default FilterSection;
