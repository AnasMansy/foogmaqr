// // src/pages/OfficeForm.js
// import React, { useState } from 'react';

// const OfficeForm = ({ buildings, setBuildings, selectedBuilding, setSelectedBuilding }) => {
//   const [officeName, setOfficeName] = useState('');

//   const addOffice = () => {
//     if (officeName && selectedBuilding) {
//       const updatedBuildings = buildings.map((building) =>
//         building.name === selectedBuilding
//           ? { ...building, offices: [...building.offices, { name: officeName, employees: [] }] }
//           : building
//       );
//       setBuildings(updatedBuildings);
//       setOfficeName('');
//     }
//   };

//   return (
//     <div className="form-section">
//       <h2>Add Office</h2>
//       <select
//         value={selectedBuilding}
//         onChange={(e) => setSelectedBuilding(e.target.value)}
//       >
//         <option value="">Select Building</option>
//         {buildings.map((building) => (
//           <option key={building.name} value={building.name}>
//             {building.name}
//           </option>
//         ))}
//       </select>
//       <input
//         type="text"
//         value={officeName}
//         onChange={(e) => setOfficeName(e.target.value)}
//         placeholder="Office Name"
//       />
//       <button onClick={addOffice}>Add Office</button>
//     </div>
//   );
// };

// export default OfficeForm;


// src/componants/OfficeForm.js
import React, { useState } from 'react';

const OfficeForm = ({ buildings, setBuildings }) => {
  const [officeName, setOfficeName] = useState('');
  const [selectedBuilding, setSelectedBuilding] = useState('');
  const [editingOffice, setEditingOffice] = useState(null);

  const handleAddOrUpdateOffice = () => {
    if (editingOffice) {
      // Update existing office
      setBuildings((prevBuildings) =>
        prevBuildings.map((building) =>
          building.name === selectedBuilding
            ? {
                ...building,
                offices: building.offices.map((office) =>
                  office.name === editingOffice.name
                    ? { ...office, name: officeName }
                    : office
                ),
              }
            : building
        )
      );
      setEditingOffice(null);
    } else {
      // Add new office
      setBuildings((prevBuildings) =>
        prevBuildings.map((building) =>
          building.name === selectedBuilding
            ? {
                ...building,
                offices: [...building.offices, { name: officeName, employees: [] }],
              }
            : building
        )
      );
    }
    // Reset fields
    setOfficeName('');
    setSelectedBuilding('');
  };

  const handleEdit = (office) => {
    setOfficeName(office.name);
    setSelectedBuilding(office.building);
    setEditingOffice(office);
  };

  const handleDelete = (buildingName, officeName) => {
    setBuildings((prevBuildings) =>
      prevBuildings.map((building) =>
        building.name === buildingName
          ? {
              ...building,
              offices: building.offices.filter((office) => office.name !== officeName),
            }
          : building
      )
    );
  };

  return (
    <div>
      <h2>اضف اداره</h2>
      <select
        value={selectedBuilding}
        onChange={(e) => setSelectedBuilding(e.target.value)}
      >
        <option value="">Select Building</option>
        {buildings.map((building) => (
          <option key={building.name} value={building.name}>
            {building.name}
          </option>
        ))}
      </select>

      <input
        type="text"
        value={officeName}
        onChange={(e) => setOfficeName(e.target.value)}
        placeholder="Office Name"
      />
      <button onClick={handleAddOrUpdateOffice}>
        {editingOffice ? 'Update Office' : 'Add Office'}
      </button>

    
      
    </div>
  );
};

export default OfficeForm;
