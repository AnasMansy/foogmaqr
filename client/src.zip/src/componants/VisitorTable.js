// src/pages/VisitorTable.js
import React from 'react';
import VisitorRow from './VisitorRow';

const VisitorTable = ({ visitors }) => {
  return (
    <table className="visitors-table">
      <thead>
        <tr>
          <th>الاسم</th>
          <th>الهاتف</th>
          <th>المبني</th>
          <th>الاداره</th>
          <th>الموظف</th>
          <th>الرقم القومي </th>
        </tr>
      </thead>
      <tbody>
        {visitors.length > 0 ? (
          visitors.map((visitor, index) => <VisitorRow key={index} visitor={visitor} />)
        ) : (
          <tr>
            <td colSpan="6" className="no-data">لا يوجد عملاء حاليا</td>
          </tr>
        )}
      </tbody>
    </table>
  );
};

export default VisitorTable;
