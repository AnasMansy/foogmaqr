// // src/pages/Dashboard.js
// import React, { useState } from 'react';
// import './Dashboard.css'; 
import BuildingForm from '../componants/BuildingForm';
import OfficeForm from '../componants/OfficeForm';
import EmployeeForm from '../componants/EmployeeForm';
import BuildingTable from '../componants/BuildingTable';


// const Dashboard = () => {
//     const [buildings, setBuildings] = useState([]);
//     const [selectedBuilding, setSelectedBuilding] = useState('');
//     const [selectedOffice, setSelectedOffice] = useState('');
//     const [searchTerm, setSearchTerm] = useState('');
  
//     return (
//       <div className="dashboard">
//       <div className="inputs">
//        <h1>Building Management Dashboard</h1>
        
//         <BuildingForm 
//           buildings={buildings}
//           setBuildings={setBuildings}
//         />
        
//         <OfficeForm 
//           buildings={buildings} 
//           setBuildings={setBuildings}
//           selectedBuilding={selectedBuilding} 
//           setSelectedBuilding={setSelectedBuilding}
//         />
  
//         <EmployeeForm 
//           buildings={buildings} 
//           setBuildings={setBuildings}
//           selectedBuilding={selectedBuilding} 
//           setSelectedBuilding={setSelectedBuilding} 
//           selectedOffice={selectedOffice} 
//           setSelectedOffice={setSelectedOffice}
//         />
  
//         {/* Search Bar for Filtering */}
//         <div className="search-section">
//           <input
//             type="text"
//             value={searchTerm}
//             onChange={(e) => setSearchTerm(e.target.value)}
//             placeholder="Search buildings, offices, or employees"
//           />
//         </div>
//       </div>
       
  
//         <BuildingTable 
//           buildings={buildings} 
//           searchTerm={searchTerm} 
//           setBuildings={setBuildings} 
//           setSelectedBuilding={setSelectedBuilding} 
//           setSelectedOffice={setSelectedOffice} 
//         />
//       </div>
//     );
//   };
  
//   export default Dashboard;

// src/componants/Dashboard.js
import React, { useState } from 'react';
import './Dashboard.css'; 
 

const Dashboard = () => {
  const [buildings, setBuildings] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const handleEditEmployee = (employee) => {
    // Logic to edit employee
  };

  const handleDeleteEmployee = (employeeId) => {
    setEmployees((prevEmployees) => prevEmployees.filter((emp) => emp.id !== employeeId));
  };
  return (
    <div className="dashboard">
    <div className="inputs">
      
      
      <BuildingForm 
        buildings={buildings}
        setBuildings={setBuildings}
      />
      
      <OfficeForm 
        buildings={buildings} 
        setBuildings={setBuildings}
      />

      <EmployeeForm 
        buildings={buildings} 
        setBuildings={setBuildings}
        employees={employees}
        setEmployees={setEmployees}
      />

    
</div>

<div className="displays">
<h2>تحديث معلومات الموظفين</h2>

{/* Search Bar for Filtering */}
      <div className="search-section">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search employees"
        />
      </div>
      <BuildingTable
      buildings={buildings}
      employees={employees}
      handleEditEmployee={handleEditEmployee}
      handleDeleteEmployee={handleDeleteEmployee}
    />
      
      </div>
    </div>
  );
};

export default Dashboard;
