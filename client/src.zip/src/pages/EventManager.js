// src/pages/EventManager.js
import React, { useState } from 'react';
import './EventManager.css';

const EventManager = () => {
  const [events, setEvents] = useState([]);
  const [currentEvent, setCurrentEvent] = useState({ name: '', company: '', client: '', date: '' });
  const [isEditing, setIsEditing] = useState(false);

  // Handle form input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentEvent((prev) => ({ ...prev, [name]: value }));
  };

  // Add or update event
  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEditing) {
      setEvents((prev) =>
        prev.map((event) => (event.id === currentEvent.id ? currentEvent : event))
      );
    } else {
      setEvents((prev) => [...prev, { ...currentEvent, id: Date.now() }]);
    }
    setCurrentEvent({ name: '', company: '', client: '', date: '' });
    setIsEditing(false);
  };

  // Edit event
  const handleEdit = (event) => {
    setCurrentEvent(event);
    setIsEditing(true);
  };

  // Delete event
  const handleDelete = (id) => {
    setEvents((prev) => prev.filter((event) => event.id !== id));
  };

  return (
    <div className="manage-events">
    <form onSubmit={handleSubmit}>
    <h1>اضف مؤتمر</h1>
        <input
          type="text"
          name="name"
          value={currentEvent.name}
          placeholder="عنوان المؤتمر"
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="company"
          value={currentEvent.company}
          placeholder="ممثل جهاز مستقبل مصر"
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="client"
          value={currentEvent.client}
          placeholder="العميل"
          onChange={handleChange}
          required
        />
        <input
          type="date"
          name="date"
          value={currentEvent.date}
          onChange={handleChange}
          required
        />
        <button type="submit">{isEditing ? 'Update Event' : 'Add Event'}</button>
      </form>

      <div className="event-list">
        <h1>قائمه المؤتمرات</h1>
        {events.length > 0 ? (
          <ul>
            {events.map((event) => (
              <li key={event.id}>
                <span>{event.name} - {event.company} - {event.client} - {new Date(event.date).toLocaleDateString()}</span>
                <button onClick={() => handleEdit(event)}>Edit</button>
                <button onClick={() => handleDelete(event.id)}>Delete</button>
              </li>
            ))}
          </ul>
        ) : (
          <h2>لايوجد مؤتمر</h2>
        )}
      </div>
    </div>
  );
};

export default EventManager;
