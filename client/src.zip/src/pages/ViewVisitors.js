// src/pages/ViewVisitors.js
import React, { useState, useEffect } from 'react';
import './ViewVisitors.css';
import FilterSection from '../componants/FilterSection';
import VisitorTable from '../componants/VisitorTable';
import logo from '../images/logo.png'
const visitorData = [
  {
    name: 'جون دو',
    phone: '123456789',
    building: 'الجناح الايسر',
    office: '101',
    employee: 'أليس جونسون',
    nationalID: '31235028789225',
    date: '2024-10-30'
  },
  {
    name: 'جين سميث',
    phone: '987654321',
    building: 'الجناح الايمن',
    office: '202',
    employee: 'بوب براون',
    nationalID: '31435024389225',
    date: '2024-10-29'
  },
  {
    name: 'مايكل ديفيس',
    phone: '555666777',
    building: 'الهندسيه',
    office: '303',
    employee: 'تشارلي جرين',
    nationalID: '31255024789225',
    date: '2024-10-28'
  },
  {
    name: 'ليندا تايلور',
    phone: '444555666',
    building: 'المالية',
    office: '404',
    employee: 'إيف آدامز',
    nationalID: '31235024789225',
    date: '2024-10-27'
  },
  {
    name: 'علي الأحمد',
    phone: '333222111',
    building: 'الاوسط',
    office: '505',
    employee: 'طارق صالح',
    nationalID: '31155028789245',
    date: '2024-10-26'
  },
  {
    name: 'سارة ناصر',
    phone: '222111333',
    building: 'الهندسيه',
    office: '606',
    employee: 'ريم خليل',
    nationalID: '31055024789234',
    date: '2024-10-25'
  },
  {
    name: 'خالد عبدالله',
    phone: '777888999',
    building: 'الجناح الايمن',
    office: '707',
    employee: 'جميل مصطفى',
    nationalID: '31245028789228',
    date: '2024-10-24'
  }
];


const ViewVisitors = () => {
  const [filteredVisitors, setFilteredVisitors] = useState(visitorData);
  const [filters, setFilters] = useState({
    name: '',
    phone: '',
    building: '',
    office: '',
    date: ''
  });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  useEffect(() => {
    const filtered = visitorData.filter(visitor => {
      return (
        (!filters.name || visitor.name.includes(filters.name)) &&
        (!filters.phone || visitor.phone.includes(filters.phone)) &&
        (!filters.building || visitor.building === filters.building) &&
        (!filters.office || visitor.office === filters.office)
        // Add date filtering logic here if needed
      );
    });
    setFilteredVisitors(filtered);
  }, [filters]);

  return (
    <div className="view-visitors-container">
  
      <h1>عرض العملاء</h1>
      <FilterSection filters={filters} onFilterChange={handleFilterChange} />
      <VisitorTable visitors={filteredVisitors} />
    </div>
  );
};

export default ViewVisitors;
