import React, { useState, useEffect } from 'react';
import './VisitorForm.css';

// Mock data for buildings, offices, employees, and initial visitors
const buildingsData = ['هندسيه', 'ماليه', 'ايسر', 'ايمن', 'Hr', 'الاوسط'];
const officesData = { 'هندسيه': ['Office 1', 'Office 2'], 'ماليه': ['Office A', 'Office B'] };
const employeesData = {
  'Office 1': ['Employee A', 'Employee B'],
  'Office A': ['Employee X', 'Employee Y']
};
let mockVisitorData = [
  { id: 1, name: 'John Doe', phone: '1234567890', destination: 'Office 1', reason: 'Meeting', company: 'Company X' },
  { id: 2, name: 'Jane Smith', phone: '0987654321', destination: 'Office A', reason: 'Interview', company: 'Company Y' }
];

const VisitorForm = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [visitorData, setVisitorData] = useState(mockVisitorData);
  const [formData, setFormData] = useState({
    id: null,
    name: '',
    phone: '',
    building: '',
    destination: '',
    employee: '',
    reason: '',
    company: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [filteredOffices, setFilteredOffices] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);

  // Load offices based on selected building
  useEffect(() => {
    if (formData.building) {
      setFilteredOffices(officesData[formData.building] || []);
    }
  }, [formData.building]);

  // Load employees based on selected office
  useEffect(() => {
    if (formData.destination) {
      setFilteredEmployees(employeesData[formData.destination] || []);
    }
  }, [formData.destination]);

  // Handle search
  const handleSearch = () => {
    const visitor = visitorData.find(v => v.name.toLowerCase() === searchTerm.toLowerCase() || v.phone === searchTerm);
    if (visitor) {
      setFormData(visitor);
      setIsEditing(true);
    } else {
      alert("Visitor not found.");
    }
  };

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

// Add state for notifications
const [notification, setNotification] = useState('');

const handleSubmit = (e) => {
  e.preventDefault();
  if (isEditing) {
    setVisitorData(visitorData.map(v => (v.id === formData.id ? formData : v)));
    setNotification('Visitor updated successfully');
  } else {
    const newVisitor = { ...formData, id: Date.now() };
    setVisitorData([...visitorData, newVisitor]);
    setNotification('New visitor added');
  }
  resetForm();
  setTimeout(() => setNotification(''), 3000); // Clear after 3 seconds
};


  // Delete visitor
  const handleDelete = (id) => {
    setVisitorData(visitorData.filter(v => v.id !== id));
    resetForm();
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      id: null,
      name: '',
      phone: '',
      building: '',
      destination: '',
      employee: '',
      reason: '',
      company: ''
    });
    setIsEditing(false);
  };





  
  return (

    <div className="visitor-form-container">
 
      <h1>تسجيل عميل</h1>

      {/* Search Section */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="ابحث بالاسم او الهاتف"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
        <button onClick={handleSearch} className="search-button">
          <i className="fas fa-search button-icon"></i> بحث
        </button>
      </div>

    {/* Display notification if present */}
    {notification && <div className="notification">{notification}</div>}

      {/* Visitor Form */}
      <form onSubmit={handleSubmit} className="visitor-form">
        <div className="form-group">
          <label>الاسم</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="ادخل الاسم"
            required
          />
        </div>

        <div className="form-group">
          <label>الهاتف</label>
          <input
            type="text"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="رقم الهاتف"
            required
          />
        </div>

        <div className="form-group">
          <label>المبنى</label>
          <select name="building" value={formData.building} onChange={handleChange} required>
            <option value="">اختر المبنى</option>
            {buildingsData.map((building, index) => (
              <option key={index} value={building}>{building}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>المكتب</label>
          <select name="destination" value={formData.destination} onChange={handleChange} required>
            <option value="">اختر المكتب</option>
            {filteredOffices.map((office, index) => (
              <option key={index} value={office}>{office}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>الموظف</label>
          <select name="employee" value={formData.employee} onChange={handleChange} required>
            <option value="">اختر الموظف</option>
            {filteredEmployees.map((employee, index) => (
              <option key={index} value={employee}>{employee}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>سبب الزياره</label>
          <input
            type="text"
            name="reason"
            value={formData.reason}
            onChange={handleChange}
            placeholder="السبب"
            required
          />
        </div>

        <div className="form-group">
          <label>اسم الشركه</label>
          <input
            type="text"
            name="company"
            value={formData.company}
            onChange={handleChange}
            placeholder="اسم الشركه"
            required
          />
        </div>

        <button type="submit" className="submit-button">
          {isEditing ? 'تحديث' : 'سجل'}
        </button>
        {isEditing && (
          <button type="button" onClick={() => handleDelete(formData.id)} className="delete-button">
            حذف
          </button>
        )}
      </form>
    </div>
  );
};

export default VisitorForm;
